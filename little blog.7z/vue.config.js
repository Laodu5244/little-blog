module.exports = {
  lintOnSave: false,
}
