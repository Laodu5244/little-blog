后端:
npm install 
node server

前端:
npm run serve

打包:
npm run build