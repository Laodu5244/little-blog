<template>
  <div class="home">
    <Cover></Cover>
    <LeftNav></LeftNav>
    <div class="main">
      <Header></Header>
      <Show></Show>
    </div>
    <!-- user -->
    <div class="user">
      <button @click="asdf">asd</button>{{user}}</div>
  </div>
</template>

<script>
import Cover from "@/components/Cover.vue";
import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";
import LeftNav from "@/components/LeftNav.vue";
import Show from "@/components/Show.vue";

export default {
  components: {
    Header,
    Footer,
    LeftNav,
    Cover,
    Show,
  },
  data(){
    return {
      user:{}
    }
  },
  mounted(){
    
  },
  methods:{
    asdf(){
      this.$bus.$on('user',(data)=>{
        this.user  = data
        
      }) 
      console.log(this.user)
    }
  }
};
</script>

<style scoped lang="less">
.home {
  position: relative;
}
.main {
  position: absolute;
  bottom: 5px;
  left: 168px;
  right: 0;
}
.user{
  position: fixed;
  top: 20px;
  right: 20px;
  background-color: rgba(17, 157, 26,0.3);
  color: #fff;
  padding: 10px;
  padding-top: 5px;
  font-size: 24px;
}
.user:hover{
  background-color: rgba(17, 157, 26,0.8);
}
</style>
