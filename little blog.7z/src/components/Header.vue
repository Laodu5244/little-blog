<template>
  <div class="header" ref="head">
    <div class="logo" @click="toHome" title="返回首页">
      <div class="text">摇滚不死</div>
    </div>
    <div class="nav">
      <router-link to="/" exact>博客列表</router-link>
      <router-link to="/add" exact>添加博客</router-link>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    toHome() {
      this.$router.push("/");
    },
  },
};
</script>

<style lang="less" scoped>
.header {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  box-shadow: 0 0 20px rgba(65, 184, 131, 0.5);
  height: 80px;
  background: #41b883;
  display: flex;
  justify-content: space-around;
  padding: 0 30px;
  z-index: 999;
  .logo {
    cursor: pointer;
    display: flex;
    align-items: center;
    .text {
      margin-left: 12px;
      color: #f4f4f4;
      font-size: 20px;
      font-style: italic;
    }
  }
  .nav {
    display: flex;
    align-items: center;
    a {
      display: inline-block;
      border-radius: 15px;
      margin: 5px;
      padding: 5px 10px;
      font-size: 16px;
      color: #f4f4f4;
      &.router-link-active {
        background-color: #f4f4f4;
        color: #41b883;
      }
    }
  }
}
</style>
