<template>
  <div class="footer">
    <div>微信 : 15031385244</div>
    <div>邮箱 : laodu5244@163.com</div>
  </div>
</template>

<style lang="less" scoped>
.footer {
  box-shadow: 0 0 20px rgba(65, 184, 131, 0.5);
  position: fixed;
  left:168px;
  right:0;
  bottom: 0;
  height: 64px;
  background: #41b883;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #f4f4f4;
  div {
    font-size: 18px;
    margin: 0 4vw;
  }
}
</style>